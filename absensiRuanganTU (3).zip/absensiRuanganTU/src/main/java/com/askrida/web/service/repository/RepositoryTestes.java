package com.askrida.web.service.repository;

public class RepositoryTestes {

}
