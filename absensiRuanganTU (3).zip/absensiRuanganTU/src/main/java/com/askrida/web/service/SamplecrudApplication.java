package com.askrida.web.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamplecrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamplecrudApplication.class, args);
	}

}
